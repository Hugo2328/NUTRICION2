//import createHistory from 'history/createBrowserHistory';
import { createBrowserHistory } from 'history';
/**
 * Permite redirigir a una determinada ruta.
 */
export default createBrowserHistory();