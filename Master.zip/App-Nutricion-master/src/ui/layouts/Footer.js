import React from 'react';

const Footer = () => (
    <div className="ui clearing segment">
        <h3 className="ui center aligned header">- Nutri&Vida -</h3>
    </div>
)

export default Footer;