import React from 'react';

const EnDesarrollo=()=>{
    return(
        <div className="ui segment">
            <i className="exclamation triangle icon"/>
            <h1>Pagina En Desarrollo</h1>
        </div>
    );
};

export default EnDesarrollo;